package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
public class PedidoServiceImpl implements IPedidoService{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar en el micro-servicio-producto el producto con ese id
		Producto producto = clienteFeign.buscar(id);
		
		return new Pedido(producto, cantidad);
	}

}
