package es.cetelem.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.cetelem.business.ItfzProductosBS;
import es.cetelem.models.Carrito;

@Controller
@RequestMapping("/")
public class ComprarController {
	
	@Autowired
	private ItfzProductosBS productosBS;
	
	@RequestMapping(method = RequestMethod.POST, value = "comprar")
	public String addPedido(long id, int cantidad, HttpServletRequest request) {
		
		String usuario = null;
		boolean logado = false;
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ( "nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
				logado = true;
			}
		}
		
		// Si no encuentro la cookie le mando logarse
		if (!logado) return "formLogin";
		
		// Si encuentro la cookie con el nombre del usuario
		// agrego el pedido
		// Recupero el carrito y lo guardo como atribito de peticion
		productosBS.agregar(id, cantidad, usuario);
		Carrito carrito = productosBS.consultar(usuario);
		request.setAttribute("carrito", carrito);
		
		
		return "mostrarCarrito";
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "sacar")
	public String eliminarPedido(long id, HttpServletRequest request) {
		
		String usuario = null;
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ( "nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
			}
		}
		 
		productosBS.eliminar(id, usuario);
		Carrito carrito = productosBS.consultar(usuario);
		request.setAttribute("carrito", carrito);
		
		return "mostrarCarrito";
	}

}
