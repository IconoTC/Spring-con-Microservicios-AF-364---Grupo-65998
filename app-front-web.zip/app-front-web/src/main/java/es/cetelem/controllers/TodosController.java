package es.cetelem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import es.cetelem.business.ItfzProductosBS;
import es.cetelem.models.Producto;

@Controller
@RequestMapping("/")
public class TodosController {
	
	@Autowired
	private ItfzProductosBS productosBS;
	
	@RequestMapping(value = "todos")
	public String execute(Model modelo) {
		List<Producto> lista = productosBS.obtenerTodos();
		modelo.addAttribute("lista", lista);
		return "mostrarTodos";
	}

}
