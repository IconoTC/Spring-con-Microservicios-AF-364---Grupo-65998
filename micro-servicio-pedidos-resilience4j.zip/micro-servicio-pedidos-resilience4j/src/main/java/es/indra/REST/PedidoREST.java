package es.indra.REST;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Pedido;
import es.indra.models.Producto;
import es.indra.services.IPedidoService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;

@RestController
public class PedidoREST {
	
	@Autowired
	private IPedidoService service;
	
	// http://localhost:8002/buscar/3/cantidad/100
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	// En el caso de recibir un error llamamos al metodo manejarError
	@CircuitBreaker(name="pedidos", fallbackMethod = "manejarError")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	// http://localhost:8002/buscar2/3/cantidad/100
	@GetMapping("/buscar2/{id}/cantidad/{cantidad}")
	@CircuitBreaker(name="pedidos", fallbackMethod = "manejarError2")
	@TimeLimiter(name = "pedidos")
	public CompletableFuture<Pedido> crearPedido2(@PathVariable Long id, @PathVariable int cantidad) {
		Pedido pedido = service.crearPedido(id, cantidad);
		return CompletableFuture.supplyAsync(() -> pedido);
	}
	
	public CompletableFuture<Pedido> manejarError2(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "*******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio version 2");
		producto.setPrecio(0);
		
		return CompletableFuture.supplyAsync( () -> new Pedido(producto, cantidad));   
	}
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "*******************");
		System.out.println(ex.getClass() + "---------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
