package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import es.indra.models.Producto;

// Ahora la url del micro-servicio-productos la obtiene de Eureka Server
//@FeignClient(url = "localhost:8001", name = "servicio-productos")
@FeignClient(name = "servicio-productos")
public interface ProductosClienteFeign {

	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id);
}
