package es.indra.REST;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Carrito;
import es.indra.services.ICarritoService;

@RestController
public class CarritosREST {
	
	@Autowired
	private ICarritoService service;
	
	// http://localhost:8003/crear/Pepito
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return service.crear(usuario);
	}
	
	// http://localhost:8003/consultar/Pepito
	@GetMapping("/consultar/{usuario}")
	public Carrito consultar(@PathVariable String usuario) {
		return service.consultar(usuario);
	}
	
	// http://localhost:8003/agregar/id/3/cantidad/100/usuario/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public Carrito agregarPedido(@PathVariable Long id, @PathVariable int cantidad, @PathVariable String usuario) {
		return service.agregarPedido(id, cantidad, usuario);
	}
	
	// http://localhost:8003/eliminar/id/3/usuario/Pepito
	@DeleteMapping("/eliminar/id/{id}/usuario/{usuario}")
	public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return service.eliminarPedido(id, usuario);
	}

}
