package es.indra.REST;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.IProductoService;

@RestController
public class ProductoREST {
	
	@Autowired
	private IProductoService productoService;
	
	@Autowired
	private HttpServletRequest request;
	
	// Inyectar el valor de la propiedad modo del servidor de configuracion
	@Value("${configuration.modo}")
	private String texto;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
//		List<Producto> lista = productoService.consultarTodos();
//		for (Producto producto : lista) {
//			producto.setPort(request.getLocalPort());
//		}
//		return lista;
		
		return productoService.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
		
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		
		// Mostrar en que modo estoy
		System.out.println("######################## " + texto + " ####################");
		
		Producto prod = productoService.buscarProducto(id);
		
		// Si no encuentra el producto, la instancia recibida estara vacia
		// entonces lanzamos una excepcion
		if (prod.getDescripcion() == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
		
		// El producto 5 va a ser lento, superando los 2 segundos va a ser erroneo
		if (id == 5L) {
			Thread.sleep(5_000);
		}
		
		// Probar el timeout
		if (id == 1) {
			Thread.sleep(3_000);
		}
		
		
		prod.setPort(request.getLocalPort());
		return prod;
	}

}
